using System;

namespace ClearTypeBack
{
    public class ContextMenu : System.Windows.Controls.ContextMenu
    {
        static ContextMenu()
        {
            IsOpenProperty.OverrideMetadata(typeof(ContextMenu),
                new ReversedFrameworkPropertyMetadata(TransparencyHelper.HandleIsOpenChanged<System.Windows.Controls.ContextMenu>));
        }
    }
}
