using System;

namespace ClearTypeBack
{
    public class ToolTip : System.Windows.Controls.ToolTip
    {
        static ToolTip()
        {
            IsOpenProperty.OverrideMetadata(typeof(ToolTip),
                new ReversedFrameworkPropertyMetadata(TransparencyHelper.HandleIsOpenChanged<System.Windows.Controls.ToolTip>));
        }
    }
}
