using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace ClearTypeBack
{
    public class ReversedFrameworkPropertyMetadata : FrameworkPropertyMetadata
    {
        public ReversedFrameworkPropertyMetadata(PropertyChangedCallback propertyChangedCallback)
            : base(propertyChangedCallback)
        {
        }

        protected override void Merge(PropertyMetadata baseMetadata, DependencyProperty dp)
        {
            base.Merge(baseMetadata, dp);

            PropertyChangedCallback = Reverse(PropertyChangedCallback);
        }

        private static PropertyChangedCallback Reverse(PropertyChangedCallback callback)
        {
            Delegate[] delegates = callback.GetInvocationList();
            Array.Reverse(delegates);
            return (PropertyChangedCallback)Delegate.Combine(delegates);
        }
    }
}
