using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Interop;
using System.Runtime.InteropServices;
using System.Windows.Media;
using System.Reflection;

namespace ClearTypeBack
{
    public sealed class TransparencyHelper
    {
        #region IsDisabled Property

        public static bool GetIsDisabled(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsDisabledProperty);
        }

        public static void SetIsDisabled(DependencyObject obj, bool value)
        {
            obj.SetValue(IsDisabledProperty, value);
        }

        public static readonly DependencyProperty IsDisabledProperty =
            DependencyProperty.RegisterAttached("IsDisabled", typeof(bool), typeof(TransparencyHelper),
                new UIPropertyMetadata(false, OnIsDisabledPropertyChanged));

        private static void OnIsDisabledPropertyChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            Control control = o as Control;
            if (control != null)
            {
                if (control.Template == null)
                {
                    control.Loaded += OnControlLoaded;
                }
                else
                {
                    ToggleTransparency(control, !(bool)e.NewValue);
                }
            }
        }

        private static void OnControlLoaded(object sender, EventArgs e)
        {
            Control control = (Control)sender;

            control.Loaded -= OnControlLoaded;

            ToggleTransparency(control, false); // we can assume false since when loaded, it's always true
        }

        private static void ToggleTransparency(Control control, bool value)
        {
            Popup popup = control.Template.FindName("PART_Popup", control) as Popup;
            if (popup != null)
            {
                popup.AllowsTransparency = value;
            }
        }

        #endregion

        #region ToolTip and ContextMenu Common Methods

        private class Fields
        {
            static Dictionary<Type, Fields> fields = new Dictionary<Type, Fields>();

            public static Fields ForType<T>()
            {
                Type type = typeof(T);

                Fields value;
                if (!fields.TryGetValue(type, out value))
                {
                    value = new Fields(type.GetField("_parentPopup", BindingFlags.NonPublic | BindingFlags.Instance),
                        type.GetMethod("OnPopupOpened", BindingFlags.NonPublic | BindingFlags.Instance),
                        type.GetMethod("OnPopupClosed", BindingFlags.NonPublic | BindingFlags.Instance));
                    fields[type] = value;
                }

                return value;
            }

            private Fields(FieldInfo parentPopup, MethodInfo onPopupOpened, MethodInfo onPopupClosed)
            {
                this.parentPopup = parentPopup;
                this.onPopupOpened = onPopupOpened;
                this.onPopupClosed = onPopupClosed;
            }

            FieldInfo parentPopup;
            public FieldInfo ParentPopup
            {
                get { return parentPopup; }
                set { parentPopup = value; }
            }

            MethodInfo onPopupOpened;
            public MethodInfo OnPopupOpened
            {
                get { return onPopupOpened; }
                set { onPopupOpened = value; }
            }

            MethodInfo onPopupClosed;
            public MethodInfo OnPopupClosed
            {
                get { return onPopupClosed; }
                set { onPopupClosed = value; }
            }
        }

        internal static void HandleIsOpenChanged<T>(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
            {
                UIElement element = (UIElement)d;
                Fields fields = Fields.ForType<T>();
                Popup popup = fields.ParentPopup.GetValue(d) as Popup;
                if (popup == null)
                {
                    HookupParentPopup(fields, element);
                }
            }
        }

        private static void HookupParentPopup(Fields fields, UIElement element)
        {
            Popup parentPopup = new Popup();
            fields.ParentPopup.SetValue(element, parentPopup);

            parentPopup.Opened += CreateEventHandler(element, fields.OnPopupOpened);
            parentPopup.Closed += CreateEventHandler(element, fields.OnPopupClosed);
            parentPopup.SetResourceReference(Popup.PopupAnimationProperty, SystemParameters.MenuPopupAnimationKey);
            
            Popup.CreateRootPopup(parentPopup, element);
        }

        private static EventHandler CreateEventHandler(object owner, MethodInfo method)
        {
            return (EventHandler)Delegate.CreateDelegate(typeof(EventHandler), owner, method);
        }

        #endregion
    }
}
