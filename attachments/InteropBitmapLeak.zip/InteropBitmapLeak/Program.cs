﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace InteropBitmapLeak
{
    static class Program
    {
        private const string format = "Time: {0}, Process Memory: {1:#,#} KB";

        private static readonly PerformanceCounter _workingSetCounter = new PerformanceCounter("Process", "Working Set - Private",
            GetCurrentPerformanceCounterInstanceName(), true);
        private static readonly List<IntPtr> _bitmapsToDelete = new List<IntPtr>();

        [STAThread]
        static void Main(string[] args)
        {
            Test(BitmapConvertMode.InteropBitmapNoDelete);
            DeleteBitmaps();
            Test(BitmapConvertMode.InteropBitmapWithDelete);
            Test(BitmapConvertMode.Alternate);
        }

        private static void Test(BitmapConvertMode mode)
        {
            TimeSpan elapsed = CreateBitmaps(mode);
            Thread.Sleep(1000); // we sleep so the counter sample will be more accurate

            string modeString = string.Join("", mode.ToString().Select((c, i) => char.IsUpper(c) && i > 0 ? " " + c : c.ToString()).ToArray());
            Console.WriteLine(modeString);
            Console.WriteLine(new string('-', modeString.Length));
            Console.WriteLine(format, elapsed, _workingSetCounter.NextValue() / 1024);
            Console.WriteLine();
        }

        enum BitmapConvertMode
        {
            InteropBitmapNoDelete,
            InteropBitmapWithDelete,
            Alternate,
        }

        private static TimeSpan CreateBitmaps(BitmapConvertMode mode)
        {
            Stopwatch sw = Stopwatch.StartNew();
            for (int i = 0; i < 100; ++i)
            {
                using (Bitmap bitmap = new Bitmap(1000, 1000))
                {
                    if (mode == BitmapConvertMode.Alternate)
                    {
                        CreateBitmapSource(bitmap);
                    }
                    else
                    {
                        IntPtr hBitmap = bitmap.GetHbitmap();

                        var b = Imaging.CreateBitmapSourceFromHBitmap(
                            hBitmap, IntPtr.Zero, Int32Rect.Empty,
                            BitmapSizeOptions.FromEmptyOptions());

                        if (mode == BitmapConvertMode.InteropBitmapWithDelete)
                        {
                            DeleteObject(hBitmap);
                        }
                        else
                        {
                            _bitmapsToDelete.Add(hBitmap);
                        }
                    }
                }
            }
            sw.Stop();

            GC.Collect(0, GCCollectionMode.Forced);

            return sw.Elapsed;
        }

        [DllImport("gdi32.dll")]
        private static extern bool DeleteObject(IntPtr hObject);

        private static void DeleteBitmaps()
        {
            foreach (IntPtr bitmap in _bitmapsToDelete)
            {
                DeleteObject(bitmap);
            }
            GC.Collect(0, GCCollectionMode.Forced);
        }

        private static BitmapSource CreateBitmapSource(Bitmap bitmap)
        {
            Rectangle rect = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
            BitmapData bitmapData = bitmap.LockBits(rect, ImageLockMode.ReadOnly, bitmap.PixelFormat);

            BitmapSource source = BitmapSource.Create(bitmap.Width, bitmap.Height,
                bitmap.HorizontalResolution, bitmap.VerticalResolution, PixelFormats.Pbgra32, null,
                bitmapData.Scan0, bitmapData.Stride * bitmap.Height, bitmapData.Stride);

            bitmap.UnlockBits(bitmapData);

            return source;
        }

        private static string GetCurrentPerformanceCounterInstanceName()
        {
            PerformanceCounterCategory cat = new PerformanceCounterCategory("Process");

            int pid;
            string pname;
            using (Process p = Process.GetCurrentProcess())
            {
                pid = p.Id;
                pname = p.ProcessName;
            }

            string[] instances = cat.GetInstanceNames();
            foreach (string instance in instances.Where(i => i.Contains(pname)))
            {
                using (PerformanceCounter cnt = new PerformanceCounter("Process", "ID Process", instance, true))
                {
                    int val = (int)cnt.RawValue;
                    if (val == pid)
                    {
                        return instance;
                    }
                }
            }

            throw new InvalidOperationException("Could not find performance counter for current process.");
        }
    }
}
