﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Collections.Generic;

namespace ActivatorDemo
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }
    }

    public class X : Control
    {
        public override void OnApplyTemplate()
        {
            var c1 = GetTemplateChild("ic");                    // returns null
            var c2 = Template.FindName("ic", this);             // returns the MarkupExtension
            var c3 = ((MarkupExtension)c2).ProvideValue(null);  // returns the ItemsControl - luckily we don't need the IServiceProvider...

            base.OnApplyTemplate();
        }
    }

    public class ItemsControl<T> : ItemsControl
        where T : DependencyObject, new()
    {
        /// <summary>
        /// Determines if the specified item is (or is eligible to be) its own container.
        /// </summary>
        /// <param name="item">The item to check.</param>
        /// <returns>
        /// true if the item is (or is eligible to be) its own container; otherwise, false.
        /// </returns>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is T;
        }

        /// <summary>
        /// Creates or identifies the element that is used to display the given item.
        /// </summary>
        /// <returns>
        /// The element that is used to display the given item.
        /// </returns>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new T();
        }
    }
}
