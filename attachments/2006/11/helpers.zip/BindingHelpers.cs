using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.ComponentModel;
using System.Windows.Data;
using System.Windows.Markup;

namespace Helpers
{
    public static class BindingHelpers
    {
        /// <summary>
        /// Invokes the <see cref="BindingExpression.UpdateSource" /> method using the default property.
        /// </summary>
        /// <param name="o">The <see cref="DependencyObject"/> to update.</param>
        public static void UpdateSourceDefaultProperty(DependencyObject o)
        {
            string error = null;

            Type type = o.GetType();

            string defaultPropName = GetDefaultPropertyName(type);

            if (defaultPropName != null)
            {
                DependencyProperty prop = DependencyHelpers.GetDependencyProperty(o, defaultPropName);
                if (prop != null)
                {
                    BindingExpression exp = BindingOperations.GetBindingExpression(o, prop);
                    if (exp != null)
                    {
                        exp.UpdateSource();
                    }
                    else
                    {
                        error = "The default property has no binding.";
                    }
                }
                else
                {
                    error = "The default property is not a Dependency Property.";
                }
            }
            else
            {
                error = "The specified Dependency Object has no default property.";
            }

            if (error != null)
            {
                throw new InvalidOperationException(error);
            }
        }

        /// <summary>
        /// Retrieves the name of the default property for a given type
        /// by examininng the <see cref="ContentPropertyAttribute"/>
        /// and the <see cref="DefaultPropertyAttribute"/>.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>The default property name.</returns>
        private static string GetDefaultPropertyName(Type type)
        {
            object[] attrs = type.GetCustomAttributes(false);

            foreach (object attr in attrs)
            {
                if (attr is ContentPropertyAttribute)
                {
                    return (attr as ContentPropertyAttribute).Name;
                }
                if (attr is DefaultPropertyAttribute)
                {
                    return (attr as DefaultPropertyAttribute).Name;
                }
            }

            return null;
        }
    }
}
