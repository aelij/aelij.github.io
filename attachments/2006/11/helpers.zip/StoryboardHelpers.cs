using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media.Animation;
using System.Windows;

namespace Helpers
{
    public static class StoryboardHelpers
    {
        /// <summary>
        /// Switches between the To and From properties of the each <see cref="AnimationTimeline"/> in the Storyboard.
        /// </summary>
        /// <param name="storyboard">The <see cref="Storyboard"/> to reverse.</param>
        public static void Reverse(Storyboard storyboard)
        {
            foreach (AnimationTimeline anim in storyboard.Children)
            {
                DependencyProperty from = DependencyHelpers.GetDependencyProperty(anim, "From");
                DependencyProperty to = DependencyHelpers.GetDependencyProperty(anim, "To");

                if (from != null && to != null)
                {
                    object fromValue = anim.GetValue(from);
                    anim.SetValue(from, anim.GetValue(to));
                    anim.SetValue(to, fromValue);
                }
            }
        }

        /// <summary>
        /// Returns a cloned <see cref="Storyboard"/> where the To and From properties of the <see cref="AnimationTimeline"/> have been switched.
        /// </summary>
        /// <param name="storyboard">The <see cref="Storyboard"/> to reverse.</param>
        /// <returns>A cloned reversed <see cref="Storyboard"/>.</returns>
        public static Storyboard GetReversed(Storyboard storyboard)
        {
            Storyboard cloned = storyboard.Clone();

            Reverse(cloned);

            return cloned;
        }

        /// <summary>
        /// Creates and adds an <see cref="AnimationTimeline"/> to a <see cref="Storyboard"/>.
        /// </summary>
        /// <typeparam name="TAnimation">The type of the <see cref="AnimationTimeline"/>.</typeparam>
        /// <typeparam name="T">The type of the value being animated.</typeparam>
        /// <param name="storyboard">The <see cref="Storyboard"/> to add the animation to.</param>
        /// <param name="from">From value.</param>
        /// <param name="to">To value.</param>
        /// <param name="path">The property path.</param>
        /// <returns>The animation that was added to the storyboard.</returns>
        public static TAnimation AddLinearAnimation<TAnimation, T>(Storyboard storyboard, PropertyPath path, T? from, T? to, Duration duration)
            where TAnimation : AnimationTimeline, new()
            where T : struct
        {
            TAnimation timeline = new TAnimation();

            DependencyProperty fromProp = DependencyHelpers.GetDependencyProperty(timeline, "From");
            DependencyProperty toProp = DependencyHelpers.GetDependencyProperty(timeline, "To");

            if (fromProp == null || toProp == null)
            {
                throw new ArgumentException("Not a linear AnimationTimeline.", "TAnimation");
            }

            timeline.Duration = duration;
            timeline.SetValue(fromProp, from);
            timeline.SetValue(toProp, to);

            Storyboard.SetTargetProperty(timeline, path);

            storyboard.Children.Add(timeline);

            return timeline;
        }
    }
}
