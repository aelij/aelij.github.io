using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Reflection;

namespace Helpers
{
    public static class DependencyHelpers
    {
        /// <summary>
        /// Retrieves a <see cref="DependencyProperty" /> using reflection.
        /// </summary>
        /// <param name="o">The <see cref="DependencyObject"/> that contains the property.</param>
        /// <param name="propertyName">The name of the property.</param>
        /// <returns>The <see cref="DependencyProperty"/>.</returns>
        internal static DependencyProperty GetDependencyProperty(DependencyObject o, string propertyName)
        {
            DependencyProperty property = null;

            FieldInfo field = o.GetType().GetField(propertyName + "Property",
                System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public);
            
            if (field != null)
            {
                property = field.GetValue(null) as DependencyProperty;
            }

            return property;
        }
    }
}
