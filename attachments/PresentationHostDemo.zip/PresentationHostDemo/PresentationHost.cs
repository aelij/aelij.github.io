﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Markup;

namespace PresentationHostDemo
{
    [ContentProperty("Content")]
    public class PresentationHost : HwndHost
    {
        #region Fields

        private const int WS_CHILD = 0x40000000;
        private const int WS_CLIPSIBLINGS = 0x04000000;
        private const int WS_CLIPCHILDREN = 0x02000000;

        private readonly ContentPresenter _presenter;

        private HwndSource _source;

        #endregion

        #region Constructor

        public PresentationHost()
        {
            _presenter = new ContentPresenter();

            AddLogicalChild(_presenter);
        }

        #endregion

        #region Overrides

        protected override System.Collections.IEnumerator LogicalChildren
        {
            get
            {
                yield return _presenter;
            }
        }

        protected override HandleRef BuildWindowCore(HandleRef hwndParent)
        {
            _source = new HwndSource(0, WS_CHILD, 0, 0, 0, string.Empty, hwndParent.Handle);
            _source.RootVisual = _presenter;
            return new HandleRef(_source, _source.Handle);
        }

        protected override void DestroyWindowCore(HandleRef hwnd)
        {
            _source.Dispose();
            _source = null;
        }

        protected override Size MeasureOverride(Size constraint)
        {
            _presenter.Measure(constraint);
            return _presenter.DesiredSize;
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            _presenter.Arrange(new Rect(new Point(), finalSize));
            return finalSize;
        }

        #endregion

        #region Dependency Properties

        public object Content
        {
            get { return (object)GetValue(ContentProperty); }
            set { SetValue(ContentProperty, value); }
        }

        public static readonly DependencyProperty ContentProperty =
            DependencyProperty.Register("Content", typeof(object), typeof(PresentationHost), new FrameworkPropertyMetadata(OnContentChanged));

        private static void OnContentChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            ((PresentationHost)o)._presenter.Content = e.NewValue;
        }

        #endregion
    }
}
