﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ControlLocalValuesSample
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private readonly string expectedCurrentValue = "Changed Title from coercion";

        private ICommand setLocalValue;
        private ICommand coerceLocalValue;
        private ICommand clearValue;

        public Window1()
        {
            InitializeComponent();

            RootGrid.DataContext = this;
        }

        #region Command Helpers

        public ICommand SetLocalValue
        {
            get
            {
                if (setLocalValue == null)
                    setLocalValue = new DelegateCommand<object>(
                        (param) =>
                        {
                            CustomControl c = param as CustomControl;
                            c.Title = "Changed Title";
                        });

                return setLocalValue;
            }
        }

        public ICommand CoerceLocalValue
        {
            get
            {
                if (coerceLocalValue == null)
                    coerceLocalValue = new DelegateCommand<object>(
                        (param) =>
                        {
                            CustomControl c = param as CustomControl;
                            c.CoerceTitle(expectedCurrentValue);
                        });

                return coerceLocalValue;
            }
        }

        public ICommand ClearLocalValue
        {
            get
            {
                if (clearValue == null)
                    clearValue = new DelegateCommand<object>(
                        (param) =>
                        {
                            CustomControl c = param as CustomControl;
                            c.ClearValue(CustomControl.TitleProperty);
                        });

                return clearValue;
            }
        }

        #endregion Command Helpers
    }
}
