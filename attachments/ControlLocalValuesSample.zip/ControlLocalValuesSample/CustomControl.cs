﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace ControlLocalValuesSample
{
    public class CustomControl : ContentControl, INotifyPropertyChanged
    {
        private object _lastBaseValueFromCoercionCallback;
        private object _lastOldValueFromPropertyChangedCallback;
        private object _lastNewValueFromPropertyChangedCallback;
        private object _titleLocalValue;
        private ValueSource _titleValueSource;

        #region WorkingTagProperty

        public static readonly DependencyProperty WorkingTagProperty = DependencyProperty.Register(
            "WorkingTag",
            typeof(object),
            typeof(CustomControl),
            new UIPropertyMetadata("<working tag>"));

        public object WorkingTag
        {
            get { return GetValue(WorkingTagProperty); }
            set { SetValue(WorkingTagProperty, value); }
        }

        #endregion WorkingTagProperty

        #region TitleProperty

        public static readonly DependencyProperty TitleProperty = DependencyProperty.RegisterAttached(
           "Title", typeof(string),
           typeof(CustomControl),
           new FrameworkPropertyMetadata(
               null,
               FrameworkPropertyMetadataOptions.Inherits,
               new PropertyChangedCallback(OnTitlePropertyChanged),
               new CoerceValueCallback(OnCoerceTitleProperty)));

        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        private static void OnTitlePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is CustomControl)
            {
                (d as CustomControl).OnTitlePropertyChanged(e);
            }
        }

        private void OnTitlePropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            LastNewValueFromPropertyChangedCallback = e.NewValue;
            LastOldValueFromPropertyChangedCallback = e.OldValue;

            TitleValueSource = DependencyPropertyHelper.GetValueSource(this, CustomControl.TitleProperty);
            TitleLocalValue = this.ReadLocalValue(CustomControl.TitleProperty);
        }

        private static object OnCoerceTitleProperty(DependencyObject d, object baseValue)
        {
            if (d is CustomControl)
            {
                return (d as CustomControl).OnCoerceTitleProperty(baseValue);
            }
            else
            {
                return baseValue;
            }
        }

        private object OnCoerceTitleProperty(object baseValue)
        {
            LastBaseValueFromCoercionCallback = baseValue;

            if (shouldCoerceTitle)
            {
                return coercedTitle;
            }
            else
            {
                return baseValue;
            }
        }

        #endregion TitleProperty

        #region Public Properties

        public ValueSource TitleValueSource
        {
            get { return _titleValueSource; }
            private set
            {
                _titleValueSource = value;
                OnPropertyChanged("TitleValueSource");
            }
        }

        public object TitleLocalValue
        {
            get { return _titleLocalValue; }
            set
            {
                _titleLocalValue = value;
                OnPropertyChanged("TitleLocalValue");
            }
        }

        public object LastBaseValueFromCoercionCallback
        {
            get { return _lastBaseValueFromCoercionCallback; }
            set
            {
                _lastBaseValueFromCoercionCallback = value;
                OnPropertyChanged("LastBaseValueFromCoercionCallback");
            }
        }

        public object LastNewValueFromPropertyChangedCallback
        {
            get { return _lastNewValueFromPropertyChangedCallback; }
            set
            {
                _lastNewValueFromPropertyChangedCallback = value;
                OnPropertyChanged("LastNewValueFromPropertyChangedCallback");
            }
        }

        public object LastOldValueFromPropertyChangedCallback
        {
            get { return _lastOldValueFromPropertyChangedCallback; }
            set
            {
                _lastOldValueFromPropertyChangedCallback = value;
                OnPropertyChanged("LastOldValueFromPropertyChangedCallback");
            }
        }

        #endregion Public Properties

        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion INotifyPropertyChanged

        bool shouldCoerceTitle;
        string coercedTitle;
        internal void CoerceTitle(string title)
        {
            shouldCoerceTitle = true;
            coercedTitle = title;
            CoerceValue(TitleProperty);
            shouldCoerceTitle = false;
        }
    }
}
