﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace GhostContentPresenterDemo
{
    internal static class NativeMethods
    {
        #region Enums

        [Flags]
        internal enum SWP
        {
            NOSIZE = 0x0001,
            NOMOVE = 0x0002,
            NOZORDER = 0x0004,
            NOACTIVATE = 0x0010,
            FRAMECHANGED = 0x0020,
        }

        internal enum HWND
        {
            NOTOPMOST = -2,
        }

        internal enum GWL
        {
            HWNDPARENT = -8,
            EXSTYLE = -20,
        }

        [Flags]
        public enum WS_EX
        {
            DLGMODALFRAME = 0x1,
        }

        #endregion

        #region User Methods

        [DllImport("user32")]
        internal static extern void SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int x, int y, int cx, int cy, SWP uFlags);

        [DllImport("user32", EntryPoint = "GetWindowLong")]
        private static extern int IntGetWindowLong(IntPtr hWnd, GWL nIndex);

        [DllImport("user32", EntryPoint = "GetWindowLongPtr")]
        private static extern IntPtr IntGetWindowLongPtr(IntPtr hWnd, GWL nIndex);

        internal static int GetWindowLong(IntPtr hWnd, GWL nIndex)
        {
            int result = 0;
            if (IntPtr.Size == 4)
            {
                result = IntGetWindowLong(hWnd, nIndex);
            }
            else
            {
                IntPtr resultPtr = IntGetWindowLongPtr(hWnd, nIndex);
                result = (int)resultPtr.ToInt64();
            }
            return result;
        }

        [DllImport("user32", EntryPoint = "SetWindowLong")]
        private static extern int IntSetWindowLong(IntPtr hWnd, GWL nIndex, int dwNewLong);

        [DllImport("user32", EntryPoint = "SetWindowLongPtr")]
        private static extern IntPtr IntSetWindowLongPtr(IntPtr hWnd, GWL nIndex, IntPtr dwNewLong);

        internal static IntPtr SetWindowLong(IntPtr hWnd, GWL nIndex, IntPtr dwNewLong)
        {
            IntPtr result = IntPtr.Zero;
            if (IntPtr.Size == 4)
            {
                int intResult = IntSetWindowLong(hWnd, nIndex, (int)dwNewLong.ToInt64());
                result = new IntPtr(intResult);
            }
            else
            {
                result = IntSetWindowLongPtr(hWnd, nIndex, dwNewLong);
            }
            return result;
        }

        #endregion

        #region DwmApi Methods

        [DllImport("dwmapi")]
        private static extern void DwmIsCompositionEnabled([Out, MarshalAs(UnmanagedType.Bool)] out bool pfEnabled);

        internal static bool IsCompositionEnabled
        {
            get
            {
                bool result = false;
                if (Environment.OSVersion.Version.Major >= 6)
                {
                    DwmIsCompositionEnabled(out result);
                }

                return result;
            }
        }

        #endregion
    }
}
