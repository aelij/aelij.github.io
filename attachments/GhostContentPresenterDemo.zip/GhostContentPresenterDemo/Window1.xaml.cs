﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Windows.Controls.Ribbon;
using System.Windows.Interop;

namespace GhostContentPresenterDemo
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        static Window1()
        {
            CommandManager.RegisterClassCommandBinding(typeof(UIElement), new CommandBinding(AppCommands.Help, OnIgnore));
            CommandManager.RegisterClassCommandBinding(typeof(UIElement), new CommandBinding(AppCommands.Paste, OnIgnore));
        }

        public Window1()
        {
            InitializeComponent();

            SourceInitialized += new EventHandler(Window1_SourceInitialized);
        }

        private void Window1_SourceInitialized(object sender, EventArgs e)
        {
            HideWindowIcon();
        }

        private void HideWindowIcon()
        {
            IntPtr handle = new WindowInteropHelper(this).Handle;

            // change the extended window style to not show a window icon
            int extendedStyle = NativeMethods.GetWindowLong(handle, NativeMethods.GWL.EXSTYLE);
            NativeMethods.SetWindowLong(handle, NativeMethods.GWL.EXSTYLE, (IntPtr)(extendedStyle | (int)NativeMethods.WS_EX.DLGMODALFRAME));

            // update the window's non-client area to reflect the changes
            NativeMethods.SetWindowPos(handle, IntPtr.Zero, 0, 0, 0, 0,
                NativeMethods.SWP.NOMOVE | NativeMethods.SWP.NOSIZE | NativeMethods.SWP.NOZORDER | NativeMethods.SWP.FRAMECHANGED);
        }

        private static void OnIgnore(object sender, ExecutedRoutedEventArgs e)
        {            
        }
    }
}
