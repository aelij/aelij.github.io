﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Threading;

namespace Rss2Cxml
{
    public class UriImageCreator
    {
        private const int MaximumDimension = 5000;

        private static ManualResetEventSlim _dispatcherCreationEvent;
        private static Dispatcher _dispatcher;

        private readonly object _lock;

        private int _width;
        private int _height;
        private Stream _outputStream;
        private WebBrowser _webBrowser;

        public static void Start()
        {
            Stop();

            _dispatcherCreationEvent = new ManualResetEventSlim();

            var thread = new Thread(new ThreadStart(RunWorkerThread));
            thread.IsBackground = true;
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();

            _dispatcherCreationEvent.Wait();
        }

        private static void RunWorkerThread()
        {
            try
            {
                _dispatcher = Dispatcher.CurrentDispatcher;
                _dispatcherCreationEvent.Set();
                Dispatcher.Run();
            }
            catch (Exception exception)
            {
                Console.WriteLine("Caught exception in rendering thread: {0}", exception);
            }
        }

        public static void Stop()
        {
            if (_dispatcherCreationEvent != null)
            {
                _dispatcherCreationEvent.Dispose();
                _dispatcherCreationEvent = null;
            }

            if (_dispatcher != null)
            {
                _dispatcher.InvokeShutdown();
                _dispatcher = null;
            }
        }

        public UriImageCreator()
        {
            _lock = new object();

            RenderTimeout = TimeSpan.FromSeconds(20);
            Width = 1200;
            Height = 1500;
        }

        public bool CreateImage(Uri uri, Stream outputStream)
        {
            if (_dispatcher == null)
            {
                throw new InvalidOperationException("Rendering thread was not started.");
            }

            if (_outputStream != null)
            {
                throw new InvalidOperationException("Already creating an image");
            }
            _outputStream = outputStream;
            bool succeeded = false;
            try
            {
                lock (_lock)
                {
                    _dispatcher.BeginInvoke(new Action<Uri>(CreateWebBrwoser), uri);
                    succeeded = Monitor.Wait(_lock, RenderTimeout);
                }
            }
            finally
            {
                if (_webBrowser != null)
                {
                    _webBrowser.Dispose();
                    _webBrowser = null;
                }
                _outputStream = null;
            }
            return succeeded;
        }

        private void CreateWebBrwoser(Uri uri)
        {
            _webBrowser = new WebBrowser
            {
                ScriptErrorsSuppressed = true,
                ScrollBarsEnabled = false,
                Height = _height,
                Width = _width,
                Url = uri,
            };
            _webBrowser.DocumentCompleted += OnDocumentCompleted;
        }

        private void OnDocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs args)
        {
            try
            {
                var bitmap = new Bitmap(_width, _height);
                _webBrowser.DrawToBitmap(bitmap, new Rectangle(_webBrowser.Location.X, _webBrowser.Location.Y, _webBrowser.Width, _webBrowser.Height));
                var encoder = ImageCodecInfo.GetImageEncoders()[1];
                var encoderParams = new EncoderParameters(1);
                encoderParams.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 100L);
                bitmap.Save(_outputStream, encoder, encoderParams);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
            lock (_lock)
            {
                Monitor.Pulse(_lock);
            }
        }

        public TimeSpan RenderTimeout { get; set; }

        public int Height
        {
            get { return _height; }
            set
            {
                if (value < 1)
                {
                    throw new ArgumentException("Height must be at least 1: " + value);
                }
                if (value > MaximumDimension)
                {
                    throw new ArgumentException(string.Concat(new object[] { "Height must be less than ", MaximumDimension, ": ", value }));
                }
                _height = value;
            }
        }

        public int Width
        {
            get { return _width; }
            set
            {
                if (value < 1)
                {
                    throw new ArgumentException("Width must be at least 1: " + value);
                }
                if (value > MaximumDimension)
                {
                    throw new ArgumentException(string.Concat(new object[] { "Width must be less than ", MaximumDimension, ": ", value }));
                }
                _width = value;
            }
        }
    }
}
