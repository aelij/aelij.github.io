﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using NDesk.Options;

namespace Rss2Cxml
{
    class Program
    {
        private static readonly XNamespace RootNs = "http://schemas.microsoft.com/collection/metadata/2009";
        private static readonly XNamespace ContentNs = "http://purl.org/rss/1.0/modules/content/";
        private static readonly XNamespace DcNs = "http://purl.org/dc/elements/1.1/";

        static void Main(string[] args)
        {
            string sourceUri = null, targetPath = null, title = null;
            bool forceCreateImages = false;
            var options = new OptionSet
            {
                { "source:", "Path or URI to the source RSS", s => sourceUri = s },
                { "target:", "Path to the target .cxml file", s => targetPath = s },
                { "title:", "Title of the collection", s => title = s },
                { "forceCreateImages", "Enables overwriting already existing images (default: false)", (bool b) => forceCreateImages = b }
            };
            options.Parse(args);

            if (sourceUri == null || targetPath == null || title == null)
            {
                Console.WriteLine("Rss2Xml");
                Console.WriteLine();
                options.WriteOptionDescriptions(Console.Out);
                return;
            }

            var sourceDoc = XDocument.Load(sourceUri);

            string targetDir = Path.GetDirectoryName(targetPath);
            if (!Directory.Exists(targetDir))
            {
                Directory.CreateDirectory(targetDir);
            }

            var root = new XElement(RootNs + "Collection",
                 new XAttribute("Name", title),
                 new XAttribute("SchemaVersion", "1.0"),
                 new XAttribute(XNamespace.Xmlns + "p", "http://schemas.microsoft.com/livelabs/pivot/collection/2009"),
                 new XAttribute(XNamespace.Xmlns + "xsi", "http://www.w3.org/2001/XMLSchema-instance"),
                 new XAttribute(XNamespace.Xmlns + "xsd", "http://www.w3.org/2001/XMLSchema"));
            var targetDoc = new XDocument(root);

            var categories = new XElement(RootNs + "FacetCategories",
                new XElement(RootNs + "FacetCategory", new XAttribute("Name", "Author"), new XAttribute("Type", "String")),
                new XElement(RootNs + "FacetCategory", new XAttribute("Name", "Categories"), new XAttribute("Type", "String")),
                new XElement(RootNs + "FacetCategory", new XAttribute("Name", "Publication Date"), new XAttribute("Type", "DateTime")));
            root.Add(categories);

            var items = new XElement(RootNs + "Items");
            root.Add(items);

            UriImageCreator.Start();
            ProcessItems(sourceDoc, items, targetDir, forceCreateImages);
            UriImageCreator.Stop();

            File.WriteAllText(targetPath, targetDoc.ToString());
        }

        private static void ProcessItems(XDocument sourceDoc, XElement itemsElement, string targetDir, bool forceCreateImages)
        {
            string imageDir = Path.Combine(targetDir, "images");
            if (!Directory.Exists(imageDir))
            {
                Directory.CreateDirectory(imageDir);
            }

            var invalidPathChars = Path.GetInvalidFileNameChars();

            int globalId = 0;
            var items = sourceDoc.Root.Elements().First().Elements("item").ToArray();
            Parallel.ForEach(items, item =>
            {
                int id = Interlocked.Increment(ref globalId);

                Console.WriteLine("Processing item #{0}...", id);

                var content = item.Element(ContentNs + "encoded");
                if (content != null)
                {
                    string title = item.Element("title").Value;
                    string author = item.Element(DcNs + "creator").Value;
                    string link = item.Element("link").Value;

                    // create a clean filename from the URI
                    string imageFileName = new string(link.Select(c => invalidPathChars.Contains(c) ? '_' : c).Concat(".jpg").ToArray());

                    string imagePath = Path.Combine(imageDir, imageFileName);

                    bool imageCreated = CreateImage(forceCreateImages, link, imagePath);

                    // create item and facets
                    var facets = new XElement(RootNs + "Facets");
                    var itemElement = new XElement(RootNs + "Item",
                        new XAttribute("Id", id),
                        new XAttribute("Href", link),
                        new XAttribute("Name", title),
                        facets);
                    if (imageCreated)
                    {
                        itemElement.Add(new XAttribute("Img", Path.Combine("images", imageFileName)));
                    }
                    facets.Add(new XElement(RootNs + "Facet", new XAttribute("Name", "Publication Date"),
                        new XElement(RootNs + "DateTime", new XAttribute("Value", Rfc822DateTime.Parse(item.Element("pubDate").Value)))));
                    facets.Add(new XElement(RootNs + "Facet", new XAttribute("Name", "Author"),
                        new XElement(RootNs + "String", new XAttribute("Value", author))));

                    // add categories
                    var categories = item.Elements("category")
                        .Where(e => e.Attribute("domain") != null && e.Attribute("domain").Value == "tag")
                        .Select(e => e.Value).Distinct()
                        .Select(s => new XElement(RootNs + "String", new XAttribute("Value", s))).ToArray();
                    if (categories.Length > 0)
                    {
                        var catElement = new XElement(RootNs + "Facet", new XAttribute("Name", "Categories"));
                        catElement.Add(categories);
                        facets.Add(catElement);
                    }

                    lock (itemsElement)
                    {
                        itemsElement.Add(itemElement);
                    }
                }
            });
        }

        private static bool CreateImage(bool forceCreateImages, string link, string imagePath)
        {
            bool imageCreated = false;
            if (!forceCreateImages && File.Exists(imagePath))
            {
                imageCreated = true;
            }
            else
            {
                // take a snapshot of the provided URI
                var uriImageCreator = new UriImageCreator();

                using (var imageFileStream = new FileStream(imagePath, FileMode.Create))
                {
                    try
                    {
                        imageCreated = uriImageCreator.CreateImage(new Uri(link), imageFileStream);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("  >> Error creating image: {0}", ex.Message);
                    }
                }

                if (!imageCreated)
                {
                    File.Delete(imagePath);
                }
            }
            return imageCreated;
        }
    }
}
