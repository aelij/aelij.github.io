﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GdiTextBlockTest
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    internal partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            var colors = typeof(Brushes).GetProperties().Where(p => p.PropertyType == typeof(SolidColorBrush)).Select(pi => new KeyValuePair<string, SolidColorBrush>(pi.Name, (SolidColorBrush)pi.GetValue(null, null))).ToArray();
            bgColor.ItemsSource = colors;
            bgColor.SelectedItem = colors.First(c => c.Key == "Transparent");
            fgColor.ItemsSource = colors;
            fgColor.SelectedItem = colors.First(c => c.Key == "Black");
        }

        private void ScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            ScrollViewer target = (sender == wpfScroll) ? gdiScroll : wpfScroll;
            target.ScrollToVerticalOffset(e.VerticalOffset);
        }
    }
}
