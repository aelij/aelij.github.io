﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Runtime.InteropServices;
using System.AddIn.Contract;
using System.AddIn.Pipeline;
using System.Windows.Interop;
using System.Reflection;

namespace WpfSxsHost
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        WpfSxsControls.IMyControl _control;

        public MainWindow()
        {
            InitializeComponent();

            Title = "CLR Version: " + Environment.Version;
            try
            {
                _control = (WpfSxsControls.IMyControl)Activator.CreateInstance(
                    Type.GetTypeFromCLSID(new Guid("{4F03582A-8ECA-4A27-9E4E-00AB54078592}")));
                c.Content = FrameworkElementAdapters.ContractToViewAdapter(
                    new NativeHandleContract(_control.Handle));
            }
            catch
            {
            }
        }

        class NativeHandleContract : INativeHandleContract
        {
            IntPtr _handle;

            public NativeHandleContract(IntPtr handle)
            {
                _handle = handle;
            }

            #region INativeHandleContract Members

            public IntPtr GetHandle()
            {
                return _handle;
            }

            #endregion

            #region IContract Members

            public int AcquireLifetimeToken()
            {
                return 0;
            }

            public int GetRemoteHashCode()
            {
                return 0;
            }

            public IContract QueryContract(string contractIdentifier)
            {
                return null;
            }

            public bool RemoteEquals(IContract contract)
            {
                return false;
            }

            public string RemoteToString()
            {
                return string.Empty;
            }

            public void RevokeLifetimeToken(int token)
            {

            }

            #endregion
        }
    }
}
