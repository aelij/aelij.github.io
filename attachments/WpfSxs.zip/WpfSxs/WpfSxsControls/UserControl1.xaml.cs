﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.AddIn.Pipeline;
using System.Runtime.InteropServices;
using System.AddIn.Contract;

namespace WpfSxsControls
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    internal partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();

            ver.Content = Environment.Version;
        }
    }

    [Guid("45421E7C-EA8E-4987-A669-5334795D1627")]
    public interface IMyControl
    {
        IntPtr Handle { get; }
    }

    [Guid("4F03582A-8ECA-4A27-9E4E-00AB54078592")]
    public class MyControl : IMyControl
    {
        private UserControl1 _instance;
        private INativeHandleContract _contract;

        public MyControl()
        {
            _instance = new UserControl1();
            _contract = FrameworkElementAdapters.ViewToContractAdapter(_instance);
            Handle = _contract.GetHandle();
        }

        public IntPtr Handle { get; private set; }
    }
}
