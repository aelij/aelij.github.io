﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml.Serialization;
using CommunityServer;
using CommunityServer.Blogs.Components;
using CommunityServer.Components;

namespace RestoreBlog
{
    public static class Program
    {
        private const string BaseUrl = @"http://www.sample.com";
        private const string BasePath = @"C:\Blog";
        private const string Owner = "ownerusername";
        private const string BlogAppName = "blog";

        static void Main(string[] args)
        {
            ParsePosts();
        }

        public static void DeleteAll()
        {
            Weblog section = Weblogs.GetWeblog(BlogAppName);
            CSContext context = CSContext.Current;

            BlogThreadQuery query = new BlogThreadQuery();
            query.SectionID = section.SectionID;
            query.BlogPostType = BlogPostType.Comment | BlogPostType.Trackback | BlogPostType.Post;
            query.PageSize = 1000;
            ThreadSet set = WeblogPosts.GetBlogThreads(query, false);
            foreach (WeblogPost post in set.Threads)
            {
                WeblogPosts.Delete(post, context.User.UserID);
            }
        }

        public static void WritePosts(string filename)
        {
            XmlSerializer ser = new XmlSerializer(typeof(Post[]));
            StringReader sr = new StringReader(File.ReadAllText(filename));
            Post[] posts = (Post[])ser.Deserialize(sr);
            foreach (Post post in posts)
            {
                CreatePost(post);
            }
        }

        private static void CreatePost(Post post)
        {
            CSContext context = CSContext.Current;
            Weblog section = Weblogs.GetWeblog(BlogAppName);
            WeblogPost blogPost = new WeblogPost();
            blogPost.BlogPostType = BlogPostType.Post;
            blogPost.PostType = PostContentType.HTML;
            blogPost.SectionID = section.SectionID;
            blogPost.PostConfig = section.DefaultPostConfig;
            blogPost.EnableRatings = section.EnableRatingsDefault;
            blogPost.EnableTrackBacks = section.EnableTrackbacksDefault;
            blogPost.EnableAllOwnerNotification = section.EnableAllOwnerNotification;
            blogPost.FeedbackNotificationType = section.FeedbackNotificationType;
            blogPost.ModerationType = section.ModerationTypeDefault;
            blogPost.EnableCrossPosting = section.EnableCrossPostingDefault;
            blogPost.IsLocked = false;
            blogPost.IsApproved = true;
            blogPost.Body = post.Content;
            blogPost.Subject = post.Title;
            blogPost.Categories = post.Tags.ToArray();
            blogPost.Name = post.UrlName;
            blogPost.ThreadDate = blogPost.PostDate = blogPost.UserTime = post.Date;
            int postId = -1;
            WeblogPosts.Add(blogPost, context.User, out postId);
            if (postId != -1)
            {
                foreach (Comment comment in post.Comments)
                {
                    CreateComment(context, section, postId, comment);
                }
            }
        }

        private static void CreateComment(CSContext context, Weblog section, int parentId, Comment comment)
        {
            WeblogPost blogComment = new WeblogPost();
            blogComment.TitleUrl = (comment.Url != null) ? comment.Url : string.Empty;
            blogComment.BlogPostType = BlogPostType.Comment;
            blogComment.PostType = PostContentType.HTML;
            blogComment.Subject = comment.Title;
            blogComment.Body = comment.Content;
            blogComment.Excerpt = string.Empty;
            blogComment.ParentID = parentId;
            blogComment.SectionID = section.SectionID;
            blogComment.ThreadDate = blogComment.UserTime = blogComment.PostDate = comment.Date;
            if (comment.Name != Owner)
            {
                blogComment.SubmittedUserName = (comment.Name != null) ? comment.Name : string.Empty;
            }

            int postId = -1;
            WeblogPosts.Add(blogComment, (comment.Name == Owner) ? context.User : Users.GetAnonymousUser(), out postId);

            blogComment.PostType = PostContentType.HTML;
            blogComment.Body = comment.Content;
            blogComment.SetExtendedAttribute("ModeratedBy", context.User.Username);
            blogComment.IsApproved = true;
            Hashtable hashtable = CSContext.Current.Context.Items["ExtendedAttribsToSave"] as Hashtable;
            if (hashtable != null)
            {
                foreach (object key in hashtable.Keys)
                {
                    blogComment.SetExtendedAttribute(Convert.ToString(key), Convert.ToString(hashtable[key]));
                }
            }

            WeblogPosts.Update(blogComment, context.User.UserID);
        }

        private static void ParsePosts()
        {
            Regex title = new Regex(@"<div class=""postsub"">\s*<h2>\s*([^<]+)", RegexOptions.Singleline);
            Regex date = new Regex(@"Published\s*\w+, (\w+ \d+, \d+ \d+:\d+ [AP]M)");
            Regex content = new Regex(@"<div class=""postsub"">.*?</h2>(.*?)<div class=""postfoot"">", RegexOptions.Singleline);
            Regex tag = new Regex(@" <a href=""/blog/archive/tags/.*?>([^<]+)");
            Regex attachment = new Regex(@"/blog/attachment/\d+.ashx"">([^<]+)");
            Regex urlClean = new Regex("_[0-9a-fA-F]{4}_");
            List<Post> posts = new List<Post>();
            foreach (string file in Directory.GetFiles(BasePath + @"\Cache\Posts", "*.htm"))
            {
                string postData = File.ReadAllText(file);
                
                Post post = new Post
                {
                    UrlName = urlClean.Replace(Path.GetFileNameWithoutExtension(file).Replace('-', ' '), m => char.ConvertFromUtf32(int.Parse(m.Value.Substring(3, 2) + m.Value.Substring(1, 2), NumberStyles.HexNumber))),
                    Title = HttpUtility.HtmlDecode(title.Match(postData).Groups[1].Value.Trim()),
                    Date = DateTime.ParseExact(date.Match(postData).Groups[1].Value, "MMMM dd, yyyy h:mm tt", null),
                    Content = ProcessContent(content.Match(postData).Groups[1].Value.Trim()),
                };
                post.Tags.AddRange(tag.Matches(postData).Cast<Match>().Select(m => m.Groups[1].Value));
                post.Attachments.AddRange(attachment.Matches(postData).Cast<Match>().Select(m => m.Groups[1].Value));
                post.Comments.AddRange(ParseComments(postData));

                posts.Add(post);
            }

            XmlSerializer ser = new XmlSerializer(typeof(Post[]));
            StringWriter sw = new StringWriter();
            ser.Serialize(sw, posts.ToArray());
            string data = sw.ToString();

            File.WriteAllText(BasePath + @"\Cache\posts.xml", data);
        }

        private static string ProcessContent(string content)
        {
            Regex image = new Regex(BaseUrl + @"/blog/photos/" + Owner + @"/images/(\d+)/.*?\.aspx");
            return image.Replace(content, m => BaseUrl + "/blog/images/" + FindImage(m.Groups[1].Value));
        }

        private static string FindImage(string id)
        {
            return Path.GetFileName(Directory.GetFiles(BasePath + @"\Cache\Images", id + ".*.*").First());
        }

        private static IEnumerable<Comment> ParseComments(string postData)
        {
            Regex commentSep = new Regex(@"<div class=""(commentowner|comment)"">");
            Regex title = new Regex(@"<h4>.*?<span>\s*([^<]+)", RegexOptions.Singleline);
            Regex credit = new Regex(@"<div class=""commentssubhead"">\s*\w+, (\w+ \d+, \d+ \d+:\d+ [AP]M)\s*by\s*(<a.*?title=""([^""]+)"".*?href=""([^""]+)|([^<]+))", RegexOptions.Singleline);
            Regex content = new Regex(@"</div>(.*?)(</div>\s*$|</div>\s*</div>\s*<div id=""commentform"">)", RegexOptions.Singleline | RegexOptions.Multiline);
            foreach (string commentData in commentSep.Split(postData).Skip(1).Where((s, i) => i % 2 != 0))
            {
                Match creditMatch = credit.Match(commentData);

                Comment comment = new Comment
                {
                    Title = HttpUtility.HtmlDecode(title.Match(commentData).Groups[1].Value.Trim()),
                    Date = DateTime.ParseExact(creditMatch.Groups[1].Value, "MMMM dd, yyyy h:mm tt", null),
                    Name = creditMatch.Groups[3].Success ? creditMatch.Groups[3].Value.Trim() : creditMatch.Groups[5].Value.Trim(),
                    Url = !creditMatch.Groups[3].Success || creditMatch.Groups[3].Value.Trim() == Owner ? null : creditMatch.Groups[4].Value.Trim(),
                    Content = content.Match(commentData).Groups[1].Value.Trim(),
                };

                yield return comment;
            }
        }

        private static void GetAttachments()
        {
            string baseDir = BasePath + @"\CSAttachments\";
            string saveDir = BasePath + @"\Cache\Attachments\";
            string ext = ".csattachment";

            Regex attachments = new Regex(@"/blog/attachment/(\d+).ashx"">([^<]+)", RegexOptions.IgnoreCase);
            foreach (Match match in attachments.Matches(File.ReadAllText(BasePath + @"\Cache\all.htm")))
            {
                File.Copy(baseDir + match.Groups[1].Value + ext, saveDir + match.Groups[2].Value);
            }
        }

        private static void GetPosts()
        {
            Regex articles = new Regex(@"<h2><a href=""(/blog/archive/\d+/\d+/\d+/(.+?)\.aspx)", RegexOptions.IgnoreCase);
            string all = File.ReadAllText(BasePath + @"\Cache\all.htm");
            string[] urls = articles.Matches(all).Cast<Match>().Select(m => m.Groups[1].Value).Distinct().ToArray();
            WebClient client = new WebClient();
            client.Headers.Add("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.0.5) Gecko/2008120122 Firefox/3.0.5");
            foreach (string url in urls)
            {
                string fullurl = "http://google.com/search?q=cache:" + BaseUrl + url;
                Console.WriteLine("Downloading " + fullurl);
                string filename = BasePath + @"\Cache\" + url.Substring(url.LastIndexOf('/') + 1) + ".htm";
                client.DownloadFile(fullurl, filename);
            }
        }
    }

    public class Post
    {
        public string Title { get; set; }

        public string UrlName { get; set; }

        public DateTime Date { get; set; }

        public string Content { get; set; }

        private readonly List<string> _attachments = new List<string>();
        public List<string> Attachments
        {
            get { return _attachments; }
        }

        private readonly List<string> _tags = new List<string>();
        public List<string> Tags
        {
            get { return _tags; }
        }

        private readonly List<Comment> _comments = new List<Comment>();
        public List<Comment> Comments
        {
            get { return _comments; }
        }
    }

    public class Comment
    {
        public string Title { get; set; }

        public string Url { get; set; }

        public string Name { get; set; }

        public DateTime Date { get; set; }

        public string Content { get; set; }
    }
}
