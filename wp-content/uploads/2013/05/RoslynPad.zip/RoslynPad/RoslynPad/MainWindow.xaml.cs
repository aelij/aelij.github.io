﻿using ICSharpCode.AvalonEdit.CodeCompletion;
using ICSharpCode.AvalonEdit.Highlighting;
using RoslynPad.Editor;
using RoslynPad.Formatting;
using RoslynPad.RoslynExtensions;
using System;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace RoslynPad
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        private const string DefaultSessionText = @"Enumerable.Range(0, 100).Select(t => new { M = t }).Dump();";

        private readonly ObjectFormatter _formatter;
        private readonly InteractiveManager _interactiveManager;

        private CompletionWindow _completionWindow;

        public MainWindow()
        {
            InitializeComponent();

            ConfigureEditor();

            var document = new FlowDocument { FontFamily = new FontFamily("Consolas"), FontSize = 12 };
            _formatter = new ObjectFormatter(document);
            DocViewer.Document = document;

            _interactiveManager = new InteractiveManager();
            _interactiveManager.SetDocument(Editor.AsTextContainer());
        }

        internal ObjectFormatter Formatter
        {
            get { return _formatter; }
        }

        private void ConfigureEditor()
        {
            Editor.SyntaxHighlighting = HighlightingManager.Instance.GetDefinition("C#");
            var lastSessionText = Properties.Settings.Default.LastSessionText;
            Editor.Text = string.IsNullOrEmpty(lastSessionText) ? DefaultSessionText : lastSessionText;
            Application.Current.Exit += (sender, args) =>
                                            {
                                                Properties.Settings.Default.LastSessionText = Editor.Text;
                                                Properties.Settings.Default.Save();
                                            };

            Editor.TextArea.TextEntering += OnTextEntering;
            Editor.TextArea.TextEntered += OnTextEntered;
        }

        private void OnTextEntered(object sender, TextCompositionEventArgs e)
        {
            var position = Editor.CaretOffset;
            if (position > 0 && _interactiveManager.IsCompletionTriggerCharacter(position - 1))
            {
                _completionWindow = new CompletionWindow(Editor.TextArea);
                var data = _completionWindow.CompletionList.CompletionData;
                foreach (var completionData in _interactiveManager.GetCompletion(position))
                {
                    data.Add(new AvalonEditCompletionData(completionData));
                }
                _completionWindow.Show();
                _completionWindow.Closed += delegate
                {
                    _completionWindow = null;
                };
            }
        }

        private void OnTextEntering(object sender, TextCompositionEventArgs e)
        {
            if (e.Text.Length > 0 && _completionWindow != null)
            {
                if (!char.IsLetterOrDigit(e.Text[0]))
                {
                    _completionWindow.CompletionList.RequestInsertion(e);
                }
            }
        }

        private void OnPlayCommand(object sender, RoutedEventArgs e)
        {
            Formatter.Clear();

            try
            {
                var scriptEngine = InteractiveManager.GetScriptEngine();
                var session = scriptEngine.CreateSession();
                session.Execute(Editor.Text);
            }
            catch (Exception ex)
            {
                Formatter.WriteError(ex);
            }
        }
    }
}
