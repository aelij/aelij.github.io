﻿using System;
using System.Windows.Media;
using ICSharpCode.AvalonEdit.CodeCompletion;
using ICSharpCode.AvalonEdit.Document;
using ICSharpCode.AvalonEdit.Editing;
using Roslyn.Compilers;
using Roslyn.Services;

namespace RoslynPad.Editor
{
    public class AvalonEditCompletionData : ICompletionData
    {
        private readonly CompletionItem _item;
        private object _description;

        public AvalonEditCompletionData(CompletionItem item)
        {
            _item = item;
            Text = item.DisplayText;
            Content = item.DisplayText;
            // Image = item.Glyph;
        }

        public void Complete(TextArea textArea, ISegment completionSegment, EventArgs e)
        {
            textArea.Document.Replace(completionSegment.Offset - 1, completionSegment.Length + 1, Text);
        }

        public ImageSource Image { get; private set; }
        public string Text { get; private set; }
        public object Content { get; private set; }
        public object Description
        {
            get
            {
                if (_description == null)
                {
                    _description = _item.GetDescription().ToDisplayString();
                }
                return _description;
            }
        }

        public double Priority { get; private set; }
    }
}