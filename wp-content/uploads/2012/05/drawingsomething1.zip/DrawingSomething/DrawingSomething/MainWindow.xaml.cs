﻿using System;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Media;

namespace DrawingSomething
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow
	{
	    private readonly Color[] _manyColors;
		
		public MainWindow()
		{
			InitializeComponent();
			
			var colors = typeof(Colors).GetProperties(BindingFlags.Static | BindingFlags.Public).Select(p => (Color)p.GetValue(null, null)).ToArray();
			_manyColors = Enumerable.Repeat(colors, 5).SelectMany(c => c).ToArray();
		}
		
		private void OnClickControls(object sender, RoutedEventArgs e)
		{
		    SetTemplate("OriginalColorTemplate");
		}

        private void OnClickDrawings(object sender, RoutedEventArgs e)
        {
            SetTemplate("ColorTemplate");
        }

	    private void SetTemplate(string templateName)
	    {
	        ic.ItemsSource = null;
            ic.ItemTemplate = Resources[templateName] as DataTemplate;
	        DoEvents();
	        Add();
	    }

        protected override void OnRender(DrawingContext drawingContext)
        {
            base.OnRender(drawingContext);
        }
        
		private void DoEvents()
		{
			var frame = new DispatcherFrame();
			Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle,
				new DispatcherOperationCallback(f => {((DispatcherFrame)f).Continue = false; return null;}), frame);
			Dispatcher.PushFrame(frame);
		}
		
		private void Add()
		{
			var sw = System.Diagnostics.Stopwatch.StartNew();
			ic.ItemsSource = _manyColors;
			Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => { sw.Stop(); MessageBox.Show(sw.Elapsed.ToString()); }));
		}
	}
}
