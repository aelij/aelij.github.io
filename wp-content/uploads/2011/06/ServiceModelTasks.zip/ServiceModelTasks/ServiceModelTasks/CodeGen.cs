﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.ServiceModel;
using System.Threading.Tasks;

namespace ServiceModelTasks
{
    internal class CodeGen
    {
        #region Constants

        private const MethodAttributes PropertyGetSetAttributes = MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig;
        private const string BeginMethodPrefix = "Begin";
        private const string EndMethodPrefix = "End";

        #endregion

        #region Static Reflection

        private static readonly ConstructorInfo ObjectConstructorInfo = typeof(object).GetConstructor(Type.EmptyTypes);
        private static readonly ConstructorInfo OperationContractConstructorInfo = typeof(OperationContractAttribute).GetConstructor(Type.EmptyTypes);
        private static readonly ConstructorInfo NotImplementedExceptionConstructorInfo = typeof(NotImplementedException).GetConstructor(Type.EmptyTypes);
        private static readonly ConstructorInfo ActionOfAsyncResultConstructorInfo = typeof(Action<IAsyncResult>).GetConstructors().First();

        private static readonly MethodInfo TaskGetFactoryMethod =
            StaticReflection.GetPropertyGetMethodInfo((object o) => Task.Factory);
        private static readonly PropertyInfo OperationContractAsyncPatternPropertyInfo = typeof(OperationContractAttribute).GetProperty("AsyncPattern");

        private static readonly MethodInfo GetTaskCreationOptionsMethod =
            StaticReflection.GetPropertyGetMethodInfo((ITaskContract c) => c.TaskCreationOptions);

        private static readonly MethodInfo ParameterContainerBeginInvokeMethod =
            StaticReflection.GetMethodInfo((IParameterContainer p) => p.BeginInvoke(null, null));

        private static readonly Type[] AsyncMethodParameterTypes = new[] { typeof(AsyncCallback), typeof(object) };
        private static readonly Type[] AsyncMethodParameterAndReturnTypes = new[] { typeof(AsyncCallback), typeof(object), typeof(IAsyncResult) };

        private static readonly ConstructorInfo AsyncFuncNoParameters =
            typeof(Func<AsyncCallback, object, IAsyncResult>).GetConstructors().First();

        private static readonly Type[] Funcs = new[] { typeof(Func<,,>), typeof(Func<,,,>), typeof(Func<,,,,>), typeof(Func<,,,,,>) };

        // ReSharper disable AssignNullToNotNullAttribute
        // ReSharper disable RedundantCast
        private static readonly MethodInfo[] TaskFactoryFromAsyncMethods =
            new[]
                {
                    StaticReflection.GetMethodInfo(() => Task.Factory.FromAsync((Func<AsyncCallback, object, IAsyncResult>)null, (Action<IAsyncResult>)null, null, TaskCreationOptions.None)),
                    StaticReflection.GetMethodInfo(() => Task.Factory.FromAsync((Func<string, AsyncCallback, object, IAsyncResult>)null, (Action<IAsyncResult>)null, null, null, TaskCreationOptions.None)).GetGenericMethodDefinition(),
                    StaticReflection.GetMethodInfo(() => Task.Factory.FromAsync((Func<string, string, AsyncCallback, object, IAsyncResult>)null, (Action<IAsyncResult>)null, null, null, null, TaskCreationOptions.None)).GetGenericMethodDefinition(),
                    StaticReflection.GetMethodInfo(() => Task.Factory.FromAsync((Func<string, string, string, AsyncCallback, object, IAsyncResult>)null, (Action<IAsyncResult>)null, null, null, null, null, TaskCreationOptions.None)).GetGenericMethodDefinition(),
                };
        private static readonly MethodInfo[] TaskFactoryFromAsyncMethodsWithResult =
            new[]
                {
                    StaticReflection.GetMethodInfo(() => Task.Factory.FromAsync((Func<AsyncCallback, object, IAsyncResult>)null, (Func<IAsyncResult, string>)null, null, TaskCreationOptions.None)).GetGenericMethodDefinition(),
                    StaticReflection.GetMethodInfo(() => Task.Factory.FromAsync((Func<string, AsyncCallback, object, IAsyncResult>)null, (Func<IAsyncResult, string>)null, null, null, TaskCreationOptions.None)).GetGenericMethodDefinition(),
                    StaticReflection.GetMethodInfo(() => Task.Factory.FromAsync((Func<string, string, AsyncCallback, object, IAsyncResult>)null, (Func<IAsyncResult, string>)null, null, null, null, TaskCreationOptions.None)).GetGenericMethodDefinition(),
                    StaticReflection.GetMethodInfo(() => Task.Factory.FromAsync((Func<string, string, string, AsyncCallback, object, IAsyncResult>)null, (Func<IAsyncResult, string>)null, null, null, null, null, TaskCreationOptions.None)).GetGenericMethodDefinition(),
                };
        // ReSharper enable RedundantCast
        // ReSharper enable AssignNullToNotNullAttribute

        #endregion

        #region Singleton

        private static readonly CodeGen _instance = new CodeGen();
        internal static CodeGen Instance
        {
            get { return _instance; }
        }

        #endregion

        #region Fields

        private readonly string _assemblyName;
        private readonly AssemblyBuilder _assembly;
        private readonly ModuleBuilder _module;
        private readonly Dictionary<Type, Type> _asyncInterfaceCache;
        private readonly Dictionary<Type, Type> _taskCache;

        #endregion

        #region Constructor

        private CodeGen()
        {
            _assemblyName = typeof(CodeGen).Namespace + ".Dynamic";
            string moduleName = _assemblyName + ".dll";
            _assembly = AppDomain.CurrentDomain.DefineDynamicAssembly(
                new AssemblyName(_assemblyName), AssemblyBuilderAccess.Run);
            _module = _assembly.DefineDynamicModule(moduleName);
            _asyncInterfaceCache = new Dictionary<Type, Type>();
            _taskCache = new Dictionary<Type, Type>();
        }

        #endregion

        #region Async Interface

        public Type CreateAsyncInterface<T>()
        {
            return CreateAsyncInterface(typeof(T));
        }

        public Type CreateAsyncInterface(Type sourceType)
        {
            if (sourceType == null)
            {
                throw new ArgumentNullException("sourceType");
            }
            if (!sourceType.IsInterface || !sourceType.IsPublic)
            {
                throw new ArgumentException("Type must be a public interface.", "sourceType");
            }
            if (sourceType.GetProperties().Any() || sourceType.GetEvents().Any())
            {
                throw new ArgumentException("Properties and events are not supported.", "sourceType");
            }

            lock (_asyncInterfaceCache)
            {
                Type asyncInterface;
                if (!_asyncInterfaceCache.TryGetValue(sourceType, out asyncInterface))
                {
                    // ReSharper disable AssignNullToNotNullAttribute
                    TypeBuilder type = _module.DefineType(sourceType.FullName, sourceType.Attributes);
                    // ReSharper restore AssignNullToNotNullAttribute
                    CopyCustomAttributes(sourceType.GetCustomAttributesData, type.SetCustomAttribute);
                    foreach (MethodInfo sourceMethod in sourceType.GetMethods())
                    {
                        if (IsValidMethod(sourceMethod))
                        {
                            DefineBeginMethod(type, sourceMethod);
                            DefineEndMethod(type, sourceMethod);
                        }
                    }

                    asyncInterface = type.CreateType();
                    _asyncInterfaceCache.Add(sourceType, asyncInterface);
                }
                return asyncInterface;
            }
        }

        private static void DefineBeginMethod(TypeBuilder type, MethodInfo sourceMethod)
        {
            ParameterInfo[] sourceParameters = sourceMethod.GetParameters();
            MethodBuilder beginMethod = type.DefineMethod(BeginMethodPrefix + sourceMethod.Name,
                                                          sourceMethod.Attributes,
                                                          sourceMethod.CallingConvention,
                                                          typeof(IAsyncResult),
                                                          sourceParameters.Select(p => p.ParameterType)
                                                              .Concat(AsyncMethodParameterTypes).
                                                              ToArray());
            CopyCustomAttributes(sourceMethod.GetCustomAttributesData, beginMethod.SetCustomAttribute,
                                 AddAsyncPatternToAttribute);
            foreach (ParameterInfo parameterInfo in sourceParameters)
            {
                if (parameterInfo.ParameterType.IsByRef)
                {
                    throw new NotSupportedException("Ref/Out parameters are not supported in Task-based interfaces.");
                }

                ParameterBuilder param = beginMethod.DefineParameter(parameterInfo.Position + 1, parameterInfo.Attributes, parameterInfo.Name);
                CopyCustomAttributes(parameterInfo.GetCustomAttributesData, param.SetCustomAttribute);
            }
            beginMethod.DefineParameter(sourceParameters.Length + 1, ParameterAttributes.None, "asyncCallback");
            beginMethod.DefineParameter(sourceParameters.Length + 2, ParameterAttributes.None, "asyncState");
        }

        private static void DefineEndMethod(TypeBuilder type, MethodInfo sourceMethod)
        {
            Type returnType = GetReturnType(sourceMethod);

            MethodBuilder beginMethod = type.DefineMethod(EndMethodPrefix + sourceMethod.Name,
                                                          sourceMethod.Attributes,
                                                          sourceMethod.CallingConvention,
                                                          returnType,
                                                          new[] { typeof(IAsyncResult) });
            beginMethod.DefineParameter(1, ParameterAttributes.None, "asyncResult");

        }

        #endregion

        #region Task Implementation

        public Type CreateTaskImplementation<T>()
        {
            return CreateTaskImplementation(typeof(T));
        }

        public Type CreateTaskImplementation(Type sourceType)
        {
            lock (_taskCache)
            {
                Type taskType;
                if (!_taskCache.TryGetValue(sourceType, out taskType))
                {
                    Type asyncIntefaceType = CreateAsyncInterface(sourceType);
                    string typeName = sourceType.Name + "Client";
                    if (typeName.StartsWith("I"))
                    {
                        typeName = typeName.Substring(1);
                    }
                    TypeBuilder type = _module.DefineType(sourceType.Namespace + "." + typeName, TypeAttributes.Public);
                    FieldBuilder channelField = type.DefineField("channel",
                                                                 typeof(Func<>).MakeGenericType(asyncIntefaceType),
                                                                 FieldAttributes.Private | FieldAttributes.InitOnly);

                    type.AddInterfaceImplementation(sourceType);
                    DefineTaskConstructor(type, channelField);
                    DefineTaskServiceInterface(type);

                    var innerTypes = new List<TypeBuilder>();
                    foreach (MethodInfo sourceMethod in sourceType.GetMethods())
                    {
                        if (IsValidMethod(sourceMethod))
                        {
                            TypeBuilder innerType = DefineTaskMethod(type, sourceMethod, channelField, asyncIntefaceType);
                            if (innerType != null)
                            {
                                innerTypes.Add(innerType);
                            }
                        }
                        else
                        {
                            DefineStubMethod(type, sourceMethod);
                        }
                    }
                    taskType = type.CreateType();
                    foreach (TypeBuilder typeBuilder in innerTypes)
                    {
                        typeBuilder.CreateType();
                    }
                    _taskCache.Add(sourceType, taskType);
                }
                return taskType;
            }
        }

        private static void DefineTaskServiceInterface(TypeBuilder type)
        {
            type.AddInterfaceImplementation(typeof(ITaskContract));
            DefineDefaultProperty(type, typeof(TaskCreationOptions), "TaskCreationOptions");
        }

        private static void DefineTaskConstructor(TypeBuilder type, FieldBuilder channelField)
        {
            ConstructorBuilder constructor = type.DefineConstructor(
                MethodAttributes.Public | MethodAttributes.HideBySig, CallingConventions.HasThis,
                new[] { channelField.FieldType });

            constructor.DefineParameter(1, ParameterAttributes.None, "channel");

            ILGenerator generator = constructor.GetILGenerator();

            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Call, ObjectConstructorInfo);
            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Ldarg_1);
            generator.Emit(OpCodes.Stfld, channelField);
            generator.Emit(OpCodes.Ret);
        }

        private static TypeBuilder DefineTaskMethod(TypeBuilder type, MethodInfo sourceMethod, FieldBuilder channelField, Type asyncIntefaceType)
        {
            ParameterInfo[] parameters = sourceMethod.GetParameters();
            int paramCount = parameters.Length;

            Type[] parameterTypes = parameters.Select(p => p.ParameterType).ToArray();
            MethodBuilder method = type.DefineMethod(sourceMethod.Name,
                                                     MethodAttributes.Public | MethodAttributes.Virtual | MethodAttributes.HideBySig | MethodAttributes.Final | MethodAttributes.NewSlot,
                                                     CallingConventions.HasThis,
                                                     sourceMethod.ReturnType,
                                                     parameterTypes);

            foreach (ParameterInfo parameterInfo in parameters)
            {
                method.DefineParameter(parameterInfo.Position + 1, parameterInfo.Attributes, parameterInfo.Name);
            }
            ILGenerator generator = method.GetILGenerator();
            Type returnType = GetReturnType(sourceMethod);
            bool hasResult = returnType != typeof(void);

            // TODO: this could fail in case of method overloads; same for "End" method
            MethodInfo beginMethodInfo = asyncIntefaceType.GetMethod(BeginMethodPrefix + sourceMethod.Name);

            MethodInfo channelFieldInvoke = channelField.FieldType.GetMethod("Invoke");

            // store the channel in a local variable
            generator.DeclareLocal(asyncIntefaceType);
            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Ldfld, channelField);
            generator.Emit(OpCodes.Callvirt, channelFieldInvoke);
            generator.Emit(OpCodes.Stloc_0);


            // if param count > 3, create a type that contains all parameters
            // and implements IParameterContainer for easy invocation
            bool isUsingParamContainer = paramCount > 3;
            int calculatedParamCount = paramCount;
            TypeBuilder paramContainerType = null;
            if (isUsingParamContainer)
            {
                Tuple<TypeBuilder, ConstructorBuilder> result = CreateParameterContainer(type, asyncIntefaceType, beginMethodInfo, parameters);
                paramContainerType = result.Item1;
                generator.DeclareLocal(typeof(IParameterContainer));
                calculatedParamCount = 0;

                generator.Emit(OpCodes.Ldloc_0);
                for (int i = 0; i < paramCount; i++)
                {
                    generator.Emit(OpCodes.Ldarg_S, (byte)(i + 1));
                }
                generator.Emit(OpCodes.Newobj, result.Item2);
                generator.Emit(OpCodes.Stloc_1);
            }

            generator.Emit(OpCodes.Call, TaskGetFactoryMethod);
            ConstructorInfo beginMethodFunc;
            if (isUsingParamContainer)
            {
                generator.Emit(OpCodes.Ldloc_1);
                generator.Emit(OpCodes.Dup);
                generator.Emit(OpCodes.Ldvirtftn, ParameterContainerBeginInvokeMethod);
                beginMethodFunc = AsyncFuncNoParameters;
            }
            else
            {
                generator.Emit(OpCodes.Ldloc_0);
                generator.Emit(OpCodes.Dup);
                generator.Emit(OpCodes.Ldvirtftn, beginMethodInfo);
                beginMethodFunc = paramCount == 0
                                      ? AsyncFuncNoParameters
                                      : Funcs[paramCount].MakeGenericType(
                                          parameterTypes.Concat(AsyncMethodParameterAndReturnTypes).ToArray())
                                            .GetConstructors().First();
            }
            generator.Emit(OpCodes.Newobj, beginMethodFunc);
            generator.Emit(OpCodes.Ldloc_0);
            generator.Emit(OpCodes.Dup);
            generator.Emit(OpCodes.Ldvirtftn, asyncIntefaceType.GetMethod(EndMethodPrefix + sourceMethod.Name));
            generator.Emit(OpCodes.Newobj, hasResult
                                               ? typeof(Func<,>).MakeGenericType(typeof(IAsyncResult), returnType).GetConstructors().First()
                                               : ActionOfAsyncResultConstructorInfo);
            for (int i = 0; i < calculatedParamCount; ++i)
            {
                generator.Emit(OpCodes.Ldarg_S, (byte)(i + 1));
            }
            generator.Emit(OpCodes.Ldnull);
            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Callvirt, GetTaskCreationOptionsMethod);
            MethodInfo taskMethod = hasResult
                                        ? TaskFactoryFromAsyncMethodsWithResult[calculatedParamCount].MakeGenericMethod(
                                            new[] { returnType }.Concat(parameterTypes).ToArray())
                                        : (calculatedParamCount == 0
                                              ? TaskFactoryFromAsyncMethods[0]
                                              : TaskFactoryFromAsyncMethods[calculatedParamCount].MakeGenericMethod(parameterTypes));
            generator.Emit(OpCodes.Callvirt, taskMethod);
            generator.Emit(OpCodes.Ret);

            return paramContainerType;
        }

        private static Tuple<TypeBuilder, ConstructorBuilder> CreateParameterContainer(TypeBuilder type, Type asyncInterfaceType, MethodInfo beginMethod, IEnumerable<ParameterInfo> parameters)
        {
            TypeBuilder parameterContainer = type.DefineNestedType(beginMethod.Name + "<>ParameterContainer");
            parameterContainer.AddInterfaceImplementation(typeof(IParameterContainer));

            FieldBuilder asyncInterfaceField = parameterContainer.DefineField("<>asyncInterface", asyncInterfaceType,
                                                                FieldAttributes.Private | FieldAttributes.InitOnly);
            FieldBuilder[] fields = parameters.Select(
                parameterInfo =>
                parameterContainer.DefineField(parameterInfo.Name, parameterInfo.ParameterType, FieldAttributes.Private | FieldAttributes.InitOnly)).ToArray();

            ConstructorBuilder constructor = parameterContainer.DefineConstructor(
                MethodAttributes.Public | MethodAttributes.HideBySig, CallingConventions.HasThis,
                new[] { asyncInterfaceType }.Concat(parameters.Select(p => p.ParameterType)).ToArray());

            ILGenerator ctorGenerator = constructor.GetILGenerator();

            ctorGenerator.Emit(OpCodes.Ldarg_0);
            ctorGenerator.Emit(OpCodes.Call, ObjectConstructorInfo);

            ctorGenerator.Emit(OpCodes.Ldarg_0);
            ctorGenerator.Emit(OpCodes.Ldarg_1);
            ctorGenerator.Emit(OpCodes.Stfld, asyncInterfaceField);

            for (int i = 0; i < fields.Length; i++)
            {
                ctorGenerator.Emit(OpCodes.Ldarg_0);
                ctorGenerator.Emit(OpCodes.Ldarg_S, (byte)(i + 2));
                ctorGenerator.Emit(OpCodes.Stfld, fields[i]);
            }
            ctorGenerator.Emit(OpCodes.Ret);

            MethodBuilder beginInvokeMethod = parameterContainer.DefineMethod(ParameterContainerBeginInvokeMethod.Name,
                                                                MethodAttributes.Public
                                                                | MethodAttributes.Virtual
                                                                | MethodAttributes.Final
                                                                | MethodAttributes.HideBySig
                                                                | MethodAttributes.NewSlot,
                                                                typeof(IAsyncResult),
                                                                AsyncMethodParameterTypes);

            ILGenerator beginMethodGen = beginInvokeMethod.GetILGenerator();

            beginMethodGen.Emit(OpCodes.Ldarg_0);
            beginMethodGen.Emit(OpCodes.Ldfld, asyncInterfaceField);
            foreach (FieldBuilder fieldBuilder in fields)
            {
                beginMethodGen.Emit(OpCodes.Ldarg_0);
                beginMethodGen.Emit(OpCodes.Ldfld, fieldBuilder);
            }
            beginMethodGen.Emit(OpCodes.Ldarg_1);
            beginMethodGen.Emit(OpCodes.Ldarg_2);
            beginMethodGen.Emit(OpCodes.Callvirt, beginMethod);
            beginMethodGen.Emit(OpCodes.Ret);

            return Tuple.Create(parameterContainer, constructor);
        }

        private static void DefineStubMethod(TypeBuilder type, MethodInfo sourceMethod)
        {
            MethodBuilder beginMethod = type.DefineMethod(sourceMethod.Name,
                                                          MethodAttributes.Public | MethodAttributes.Virtual | MethodAttributes.HideBySig | MethodAttributes.Final | MethodAttributes.NewSlot,
                                                          sourceMethod.CallingConvention,
                                                          sourceMethod.ReturnType,
                                                          sourceMethod.GetParameters().Select(p => p.ParameterType).ToArray());
            ILGenerator generator = beginMethod.GetILGenerator();
            generator.Emit(OpCodes.Newobj, NotImplementedExceptionConstructorInfo);
            generator.Emit(OpCodes.Throw);
        }

        #endregion

        #region Utility Methods

        private static bool IsValidMethod(MethodInfo sourceMethod)
        {
            return sourceMethod.GetCustomAttributes(typeof(OperationContractAttribute), false).Any() &&
                   typeof(Task).IsAssignableFrom(sourceMethod.ReturnType);
        }

        private static void AddAsyncPatternToAttribute(CustomAttributeData data, List<CustomAttributeNamedArgument> props)
        {
            if (data.Constructor == OperationContractConstructorInfo)
            {
                CustomAttributeNamedArgument asyncPatternProperty =
                    props.FirstOrDefault(c => c.MemberInfo == OperationContractAsyncPatternPropertyInfo);
                if (asyncPatternProperty.MemberInfo == null)
                {
                    props.Remove(asyncPatternProperty);
                }
                props.Add(new CustomAttributeNamedArgument(OperationContractAsyncPatternPropertyInfo, true));
            }
        }

        private static void CopyCustomAttributes(Func<IList<CustomAttributeData>> source, Action<CustomAttributeBuilder> setter)
        {
            CopyCustomAttributes(source, setter, null);
        }

        private static void CopyCustomAttributes(Func<IList<CustomAttributeData>> source, Action<CustomAttributeBuilder> setter, Action<CustomAttributeData, List<CustomAttributeNamedArgument>> selector)
        {
            foreach (var customAttributeData in source())
            {
                if (customAttributeData.NamedArguments != null)
                {
                    List<CustomAttributeNamedArgument> props =
                        customAttributeData.NamedArguments.Where(m => m.MemberInfo is PropertyInfo).ToList();
                    List<CustomAttributeNamedArgument> fields =
                        customAttributeData.NamedArguments.Where(m => m.MemberInfo is FieldInfo).ToList();

                    if (selector != null)
                    {
                        selector(customAttributeData, props);
                    }

                    setter(new CustomAttributeBuilder(customAttributeData.Constructor,
                                                      customAttributeData.ConstructorArguments.Select(m => m.Value).ToArray(),
                                                      props.Select(m => (PropertyInfo)m.MemberInfo).ToArray(),
                                                      props.Select(m => m.TypedValue.Value).ToArray(),
                                                      fields.Select(m => (FieldInfo)m.MemberInfo).ToArray(),
                                                      fields.Select(m => m.TypedValue.Value).ToArray()));
                }
                else
                {
                    var props = new List<CustomAttributeNamedArgument>();

                    if (selector != null)
                    {
                        selector(customAttributeData, props);
                    }

                    setter(new CustomAttributeBuilder(customAttributeData.Constructor,
                                                      customAttributeData.ConstructorArguments.Select(m => m.Value).ToArray(),
                                                      props.Select(m => (PropertyInfo)m.MemberInfo).ToArray(),
                                                      props.Select(m => m.TypedValue.Value).ToArray()));
                }
            }
        }

        private static Type GetReturnType(MethodInfo sourceMethod)
        {
            Type returnType = sourceMethod.ReturnType;
            if (returnType.IsGenericType && returnType.GetGenericTypeDefinition() == typeof(Task<>))
            {
                returnType = returnType.GetGenericArguments()[0];
            }
            else
            {
                returnType = typeof(void);
            }
            return returnType;
        }

        private static void DefineDefaultProperty(TypeBuilder type, Type propertyType, string name)
        {
            FieldBuilder taskCreationOptionsField = type.DefineField("<>" + name, propertyType, FieldAttributes.Private);

            MethodBuilder getMethodBuilder = type.DefineMethod("get_" + name,
                                                               PropertyGetSetAttributes | MethodAttributes.Virtual | MethodAttributes.Final | MethodAttributes.NewSlot,
                                                               propertyType,
                                                               Type.EmptyTypes);

            ILGenerator generator = getMethodBuilder.GetILGenerator();

            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Ldfld, taskCreationOptionsField);
            generator.Emit(OpCodes.Ret);

            MethodBuilder setMethodBuilder = type.DefineMethod("set_" + name,
                                                               PropertyGetSetAttributes | MethodAttributes.Virtual | MethodAttributes.Final | MethodAttributes.NewSlot,
                                                               null,
                                                               new[] { propertyType });

            generator = setMethodBuilder.GetILGenerator();

            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Ldarg_1);
            generator.Emit(OpCodes.Stfld, taskCreationOptionsField);
            generator.Emit(OpCodes.Ret);

            var prop = type.DefineProperty(name, PropertyAttributes.None, propertyType, null);
            prop.SetGetMethod(getMethodBuilder);
            prop.SetSetMethod(setMethodBuilder);
        }

        #endregion
    }
}
