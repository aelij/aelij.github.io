﻿using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;

namespace ServiceModelTasks
{
    internal class InnerClient<TInner> : ClientBase<TInner>, IInnerClient
        where TInner : class
    {
        #region Constructors

        public InnerClient()
        {
        }

        public InnerClient(string endpointConfigurationName)
            : base(endpointConfigurationName)
        {
        }

        public InnerClient(string endpointConfigurationName, string remoteAddress)
            : base(endpointConfigurationName, remoteAddress)
        {
        }

        public InnerClient(string endpointConfigurationName, EndpointAddress remoteAddress)
            : base(endpointConfigurationName, remoteAddress)
        {
        }

        public InnerClient(Binding binding, EndpointAddress remoteAddress)
            : base(binding, remoteAddress)
        {
        }

        public InnerClient(ServiceEndpoint endpoint)
            : base(endpoint)
        {
        }

        public InnerClient(InstanceContext callbackInstance)
            : base(callbackInstance)
        {
        }

        public InnerClient(InstanceContext callbackInstance, string endpointConfigurationName)
            : base(callbackInstance, endpointConfigurationName)
        {
        }

        public InnerClient(InstanceContext callbackInstance, string endpointConfigurationName, string remoteAddress)
            : base(callbackInstance, endpointConfigurationName, remoteAddress)
        {
        }

        public InnerClient(InstanceContext callbackInstance, string endpointConfigurationName, EndpointAddress remoteAddress)
            : base(callbackInstance, endpointConfigurationName, remoteAddress)
        {
        }

        public InnerClient(InstanceContext callbackInstance, Binding binding, EndpointAddress remoteAddress)
            : base(callbackInstance, binding, remoteAddress)
        {
        }

        public InnerClient(InstanceContext callbackInstance, ServiceEndpoint endpoint)
            : base(callbackInstance, endpoint)
        {
        }

        #endregion

        #region Channel

        public new TInner Channel
        {
            get { return base.Channel; }
        }

        object IInnerClient.Channel
        {
            get { return Channel; }
        }

        #endregion
    }
}
