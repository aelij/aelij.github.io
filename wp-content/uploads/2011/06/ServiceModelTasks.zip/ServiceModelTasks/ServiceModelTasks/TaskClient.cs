﻿using System;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.Threading.Tasks;

namespace ServiceModelTasks
{
    public class TaskClient<T> : ICommunicationObject, IDisposable
    {
        #region Fields

        private IInnerClient _innerClient;
        private T _channel;

        #endregion

        #region Constructors

        public TaskClient()
        {
            Initialize(Type.EmptyTypes);
        }

        public TaskClient(string endpointConfigurationName)
        {

            Initialize(new[] { typeof(string)}, endpointConfigurationName);
        }

        public TaskClient(string endpointConfigurationName, string remoteAddress)
        {

            Initialize(new[] { typeof(string), typeof(string) }, endpointConfigurationName, remoteAddress);
        }

        public TaskClient(string endpointConfigurationName, EndpointAddress remoteAddress)
        {

            Initialize(new[] { typeof(string), typeof(EndpointAddress) }, endpointConfigurationName, remoteAddress);
        }

        public TaskClient(Binding binding, EndpointAddress remoteAddress)
        {

            Initialize(new[] { typeof(Binding), typeof(EndpointAddress) }, binding, remoteAddress);
        }

        public TaskClient(ServiceEndpoint endpoint)
        {
            Initialize(new[] { typeof(ServiceEndpoint) }, endpoint);
        }

        public TaskClient(InstanceContext callbackInstance)
        {
            Initialize(new[] { typeof(InstanceContext) }, callbackInstance);
        }

        public TaskClient(InstanceContext callbackInstance, string endpointConfigurationName)
        {
            Initialize(new[] { typeof(InstanceContext), typeof(string) }, callbackInstance, endpointConfigurationName);
        }

        public TaskClient(InstanceContext callbackInstance, string endpointConfigurationName, string remoteAddress)
        {
            Initialize(new[] { typeof(InstanceContext), typeof(string), typeof(string) }, callbackInstance, endpointConfigurationName, remoteAddress);
        }

        public TaskClient(InstanceContext callbackInstance, string endpointConfigurationName, EndpointAddress remoteAddress)
        {
            Initialize(new[] { typeof(InstanceContext), typeof(string), typeof(EndpointAddress) }, callbackInstance, endpointConfigurationName, remoteAddress);
        }

        public TaskClient(InstanceContext callbackInstance, Binding binding, EndpointAddress remoteAddress)
        {
            Initialize(new[] { typeof(InstanceContext), typeof(Binding), typeof(EndpointAddress) }, callbackInstance, binding, remoteAddress);
        }

        public TaskClient(InstanceContext callbackInstance, ServiceEndpoint endpoint)
        {
            Initialize(new[] { typeof(InstanceContext), typeof(ServiceEndpoint) }, callbackInstance, endpoint);
        }

        #endregion

        #region Initialization

        private void Initialize(Type[] argumentTypes, params object[] args)
        {
            Type asyncInterface = CodeGen.Instance.CreateAsyncInterface<T>();
            Type taskImpl = CodeGen.Instance.CreateTaskImplementation<T>();

            try
            {
                _innerClient = (IInnerClient) typeof (InnerClient<>).MakeGenericType(asyncInterface)
                                                  .GetConstructor(argumentTypes).Invoke(args);
                _channel = (T) Activator.CreateInstance(
                    taskImpl, new[]
                                  {
                                      Delegate.CreateDelegate(
                                          typeof (Func<>).MakeGenericType(asyncInterface),
                                          _innerClient,
                                          _innerClient.GetType().GetProperty("Channel").
                                              GetGetMethod())
                                  });
            }
            catch (TargetInvocationException ex)
            {
                throw ex.InnerException;
            }
        }

        #endregion

        #region Channel

        public T Channel
        {
            get { return _channel; }
        }

        public TaskCreationOptions TaskCreationOptions
        {
            get { return ((ITaskContract)_channel).TaskCreationOptions; }
            set { ((ITaskContract)_channel).TaskCreationOptions = value; }
        }

        #endregion

        #region ICommunicationObject Implementation

        public void Abort()
        {
            _innerClient.Abort();
        }

        public IAsyncResult BeginClose(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return _innerClient.BeginClose(timeout, callback, state);
        }

        public IAsyncResult BeginClose(AsyncCallback callback, object state)
        {
            return _innerClient.BeginClose(callback, state);
        }

        public IAsyncResult BeginOpen(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return _innerClient.BeginOpen(timeout, callback, state);
        }

        public IAsyncResult BeginOpen(AsyncCallback callback, object state)
        {
            return _innerClient.BeginOpen(callback, state);
        }

        public void Close(TimeSpan timeout)
        {
            _innerClient.Close(timeout);
        }

        public void Close()
        {
            _innerClient.Close();
        }

        public event EventHandler Closed
        {
            add { _innerClient.Closed += value; }
            remove { _innerClient.Closed -= value; }
        }

        public event EventHandler Closing
        {
            add { _innerClient.Closing += value; }
            remove { _innerClient.Closing -= value; }
        }

        public void EndClose(IAsyncResult result)
        {
            _innerClient.EndClose(result);
        }

        public void EndOpen(IAsyncResult result)
        {
            _innerClient.EndOpen(result);
        }

        public event EventHandler Faulted
        {
            add { _innerClient.Faulted += value; }
            remove { _innerClient.Faulted -= value; }
        }

        public void Open(TimeSpan timeout)
        {
            _innerClient.Open(timeout);
        }

        public void Open()
        {
            _innerClient.Open();
        }

        public event EventHandler Opened
        {
            add { _innerClient.Opened += value; }
            remove { _innerClient.Opened -= value; }
        }

        public event EventHandler Opening
        {
            add { _innerClient.Opening += value; }
            remove { _innerClient.Opening -= value; }
        }

        public CommunicationState State
        {
            get { return _innerClient.State; }
        }

        #endregion

        #region IDisposable Implementation

        public void Dispose()
        {
            _innerClient.Dispose();
        }

        #endregion
    }
}
