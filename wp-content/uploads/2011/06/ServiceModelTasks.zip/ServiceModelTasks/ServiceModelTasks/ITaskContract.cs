﻿using System.Threading.Tasks;

namespace ServiceModelTasks
{
    public interface ITaskContract
    {
        TaskCreationOptions TaskCreationOptions { get; set; }
    }
}
