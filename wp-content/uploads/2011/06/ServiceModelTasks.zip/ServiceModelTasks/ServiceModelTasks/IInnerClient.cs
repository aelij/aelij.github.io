﻿using System;
using System.ServiceModel;

namespace ServiceModelTasks
{
    interface IInnerClient : ICommunicationObject, IDisposable
    {
        object Channel { get; }
    }
}
