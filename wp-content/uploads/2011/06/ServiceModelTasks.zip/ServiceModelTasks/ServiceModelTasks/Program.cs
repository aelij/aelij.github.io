﻿using System;
using System.ServiceModel;
using System.Threading.Tasks;

namespace ServiceModelTasks
{
    class Program
    {
        static void Main()
        {
            const string address = "http://localhost:8080/x";

            var host = new ServiceHost(typeof(HelloService));
            host.AddServiceEndpoint("ServiceModelTasks.IHello", new BasicHttpBinding(), address);
            host.Open();

            var taskClient = new TaskClient<IHelloAsync>(new BasicHttpBinding(), new EndpointAddress(address));
            taskClient.Channel.Greet("Seattle").ContinueWith(t => Console.WriteLine("Client print: {0}", t.Result));
            taskClient.Channel.M(0, "1", 2, "3");

            Console.WriteLine("Press <enter> to terminate.");
            Console.ReadLine();
        }
    }

    class HelloService : IHello
    {
        public string Greet(string name)
        {
            return string.Format("Hello {0}!", name);
        }

        public void M(int a, string b, int c, string d)
        {
            Console.WriteLine("Server print: {0}, {1}, {2}, {3}", a, b, c, d);
        }
    }

    [ServiceContract]
    public interface IHello
    {
        [OperationContract]
        string Greet(string name);

        [OperationContract]
        void M(int a, string b, int c, string d);
    }

    [ServiceContract(Name = "IHello")]
    public interface IHelloApm
    {
        [OperationContract(AsyncPattern = true)]
        IAsyncResult BeginGreet(string name, AsyncCallback asyncCallback, object asyncState);
        string EndGreet(IAsyncResult asyncResult);
    }

    [ServiceContract(Name = "IHello")]
    public interface IHelloAsync
    {
        [OperationContract]
        Task<string> Greet(string name);

        [OperationContract]
        Task M(int a, string b, int c, string d);
    }
}
