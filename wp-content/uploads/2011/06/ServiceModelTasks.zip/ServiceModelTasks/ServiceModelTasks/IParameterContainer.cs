﻿using System;

namespace ServiceModelTasks
{
    public interface IParameterContainer
    {
        IAsyncResult BeginInvoke(AsyncCallback asyncCallback, object asyncState);
    }
}
